
<?php $__env->startSection('title', 'Rapid Pro '); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content roleData">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title"><?php echo e($flowData->file_id); ?></h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item">
                                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                        data-target=".bs-example-modal-lg"><i class="fas fa-plus"></i>Add Question</button>
                                </li>
                            </ol>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-border card-primary">
                        <div class="card-header border-primary bg-transparent pb-0">
                            <h3 class="card-title text-secondary">
                                <input type="hidden" name="flow_id" id="flow_id" value="<?php echo e($flowData->id); ?>"
                                    id="">
                                <a href="<?php echo e(route('rapidpro.question.json', $flowData->id)); ?>"
                                    class="btn btn-success btn-sm float-left"> Export Json</a>
                            </h3>-
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr style="background-color: #a4bad0">
                                            <th class="text-center">#</th>
                                            <th class="text-center">Question Title </th>
                                            <th class="text-center">Answer Type</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $allQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th class="text-center"><?php echo e($key + 1); ?></th>
                                                <th class="text-center"><?php echo e($data->question_title); ?></th>
                                                <th class="text-center"><span
                                                        class="bg bg-success badge-pill"><?php echo e($data->ans_Type); ?></span> </th>
                                                

                                            <tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr class="text-center">
                                                <td colspan="3"><span>No data found</span> </td>
                                                
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $allQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->

        </div>
        <!-- end container-fluid -->
    </div>


    <!-- MODAL start-->

    

    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true" style="display: none;">

        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> Add Question</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php echo $__env->make('rapidflow.question.question-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    

    <script>
        $(document).on('change', '#ans_type', function() {

            var ans_type = $(this).val();

            if (ans_type == 'Input_answer') {
                $('.selectType').show();
            } else {
                $('.selectType').hide();
            }

            if (ans_type == 'multiple_Choice') {
                $('.selectMultiple').show();
            } else {
                $('.selectMultiple').hide();
            }

        });
    </script>

    <!-- script tag for addevent items -->
    <script type="text/javascript">
        $(document).ready(function() {
            var counter = 0;
            $(document).on("click", ".addQuestion", function() {
                //alert('ok');
                var whole_extra_item_add = $("#whole_extra_item_add").html();
                $(this).closest(".add_item").append(whole_extra_item_add);
                counter++;
            });
            $(document).on("click", ".removeQuestion", function() {
                //alert(delete_whole_extra_item);
                $(this).closest(".delete_whole_extra_item").remove();

                counter -= 1;
            });
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ucms-backend\resources\views/rapidflow/question/index.blade.php ENDPATH**/ ?>