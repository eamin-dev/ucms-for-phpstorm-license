<div class="left-side-menu">

    <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <div id="sidebar-menu">






















            <ul class="metismenu" id="side-menu">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?>
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="mdi mdi-home"></i>
                        <span> Dashboard </span>
                    </a>
                </li>
                <?php endif; ?>
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapid_pro')): ?>
                
               <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapid_pro')): ?>

            <li>
                <a href="javascript: void(0);" class="waves-effect">
                    <i class="mdi mdi-widgets"></i>
                    <span> Rapid Pro </span>
                    <span class="menu-arrow"></span>
                </a>
                <ul class="nav-second-level" aria-expanded="false">
                    <li><a href="<?php echo e(route('rapid.flow.view')); ?>">Rapid Pro</a></li>
                    
                    <li><a href="<?php echo e(route('get.country.office')); ?>">Country Office</a></li>
                    <li><a href="<?php echo e(route('themefic-area.view')); ?>">Themefic Area</a></li>

                </ul>
            </li>
                
            <?php endif; ?>
               
        
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('iogt')): ?>
                <li>
                    <a href="<?php echo e(route('iogt.index')); ?>" class="waves-effect">
                        <i class="mdi mdi-translate"></i>
                        <span> IoGT </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="waves-effect">
                        <i class="fas fa-user"></i>
                        <span> User </span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role')): ?>
                <li>
                    <a href="<?php echo e(route('roles.index')); ?>" class="waves-effect">
                        <i class="fas fa-user"></i>
                        <span> Role & Permission </span>
                    </a>
                </li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('user.profile.view')); ?>" class="waves-effect">
                        <i class="fas fa-wrench"></i>
                        <span> Settings </span>
                    </a>
                </li>



            </ul>
            <hr>
            <ul class="metismenu align-bottom" id="side-menu">
                <li>
                    <a href="<?php echo e(route('logout')); ?>" class="waves-effect">
                        <i class="mdi mdi-power-settings"></i>
                        <span> Logout </span>
                    </a>
                </li>
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>


    </div>
    <!-- Sidebar -left -->

</div>
<?php /**PATH C:\xampp\htdocs\ucms-backend\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>