<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2022 &copy; Developed by <a href="https://riseuplabs.com/" style="color: darkorange"><strong>Riseup Labs</strong></a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\ucms-backend\resources\views/layouts/footer.blade.php ENDPATH**/ ?>