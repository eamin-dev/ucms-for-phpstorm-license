<div class="navbar-custom">
    <ul class="list-unstyled topnav-menu float-right mb-0">


































        <li class="dropdown notification-list">
            <a class="nav-link dropdown-toggle  waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                <i class="mdi mdi-bell noti-icon"></i>
                <span class="badge badge-danger rounded-circle noti-icon-badge">3</span>
            </a>




















































        </li>

        <li class="dropdown notification-list d-none d-md-inline-block">
            <strong class="nav-link waves-effect waves-light"><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></strong>
        </li>

        <li class="dropdown notification-list">
            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                <img src="assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
            </a>
            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">

























                <!-- item-->
                <a href="<?php echo e(route('logout')); ?>" class="dropdown-item notify-item">
                    <i class="mdi mdi-power-settings"></i>
                    <span>Logout</span>
                </a>

            </div>
        </li>








    </ul>

    <!-- LOGO -->
    <div class=" logo-box">
        <a href="<?php echo e(url('/')); ?>" class="logo text-center logo-dark">
                            <span class="logo-lg">

                                <span class="logo-lg-text-light">UCMS</span>
                            </span>
            <span class="logo-sm">
                               <span class="logo-lg-text-light">UCMS</span>

                            </span>
        </a>

        <a href="<?php echo e(url('/')); ?>" class="logo text-center logo-light">
                            <span class="logo-lg">

                                <span class="logo-lg-text-light">UCMS</span>
                            </span>
            <span class="logo-sm">
                                   <span class="logo-lg-text-light">UCMS</span>

                            </span>
        </a>
    </div>

    <!-- LOGO -->

    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">






        <li class="d-none d-sm-block">
            <form class="app-search">
                <div class="app-search-box">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search...">
                        <div class="input-group-append">
                            <button class="btn" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\ucms-backend\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>