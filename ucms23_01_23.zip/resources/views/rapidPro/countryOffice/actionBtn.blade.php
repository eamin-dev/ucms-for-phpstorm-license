<button type="button" data-office-id="{{$id}}" class="showDetails btn btn-secondary btn-sm"><i class="fa fa-eye"></i> </button>
<button type="button" data-office-id="{{$id}}" class="edit btn btn-primary btn-sm"><i class="fa fa-pen"></i> </button>
<button type="button" data-office-id="{{$id}}" data-area-name="{{$name}}" class="delete btn btn-danger btn-sm"><i class="fa fa-trash"></i> </button>

