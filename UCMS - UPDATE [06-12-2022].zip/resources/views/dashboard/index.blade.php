@extends('layouts.app')
@section('title', 'Home')
@section('content')
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

           <div class="row">
               <div class="col-12 align-items-center">
                   <h1>Welcome to</h1><br>
                   <h1>UCMS</h1>
               </div>
           </div>


        </div>
        <!-- end container-fluid -->

    </div>
@endsection
